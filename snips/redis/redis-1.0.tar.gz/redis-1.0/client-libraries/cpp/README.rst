redis-cpp-client
================

* A C++ client for the Redis_ key-value database (which is hosted at github_).
* This client has no external dependencies other than g++ (no Boost for instance).
* It uses anet from antirez_ (redis' author), which is bundled.
* This client is licensed under the same license as redis. 
* Tested on Linux and Mac OS X.

* This is a work in progress. I will update this README when the client is "done".
  If I had to put a version number on it right now, I'd call it version 0.85

.. _Redis: http://code.google.com/p/redis/ 
.. _github: http://github.com/antirez/redis/tree/master
.. _antirez: https://github.com/antirez 

